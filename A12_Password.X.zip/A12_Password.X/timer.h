/* 
 * File:   timer.h
 * Author: Pranav Ahuja
 *
 * Created on October 27, 2023, 12:25 PM
 */

#ifndef TIMER_H
#define	TIMER_H

void init_timer0(void);

#endif	/* TIMER_H */

